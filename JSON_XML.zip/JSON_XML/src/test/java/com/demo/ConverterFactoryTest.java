package com.demo;

import org.junit.Before;
import org.junit.Test;

/**
 * The type Converter factory test.
 */
public class ConverterFactoryTest {

    private ConverterFactory converterFactoryUnderTest;

    /**
     * Sets up.
     */
    @Before
    public void setUp() {
        converterFactoryUnderTest = new ConverterFactory();
    }

    /**
     * Test convert json to xml.
     */
    @Test
    public void testConvertJsonToXml() {
        // Run the test
        final XMLJSONConverterI result = converterFactoryUnderTest.convertJsonToXml("inputJsonFileName", "outputXmlFileName");
    }
}
