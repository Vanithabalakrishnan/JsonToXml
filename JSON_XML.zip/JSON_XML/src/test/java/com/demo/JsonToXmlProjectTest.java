package com.demo;

import org.junit.Test;

/**
 * The type Json to xml project test.
 */
public class JsonToXmlProjectTest {

    /**
     * Test main.
     *
     * @throws Exception the exception
     */
    @Test
    public void testMain() throws Exception {
        // Setup

        // Run the test
        JsonToXmlProject.main(new String[]{"src/test/resources/json/example1.json", "src/test/resources/json/Output.xml"});

        // Verify the results
    }

    /**
     * Test main throws exception.
     *
     * @throws Exception the exception
     */
    @Test(expected = Exception.class)
    public void testMain_ThrowsException() throws Exception {
        // Setup

        // Run the test
        JsonToXmlProject.main(new String[]{"value"});
    }
}
