package com.demo;

import org.json.simple.parser.ParseException;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.IOException;

import static org.junit.Assert.assertEquals;

/**
 * The type Xmljson converter i impl test.
 */
public class XMLJSONConverterIImplTest {

    private XMLJSONConverterIImpl xmljsonConverterIImplUnderTest;

    /**
     * Sets up.
     */
    @Before
    public void setUp() {
        xmljsonConverterIImplUnderTest = new XMLJSONConverterIImpl("inputJsonFileName", "outputXmlFileName");
    }

    /**
     * Test convert jso nto xml interface.
     *
     * @throws Exception the exception
     */
    @Test
    public void testConvertJSONtoXMLInterface() throws Exception {
        // Setup

        // Run the test
        xmljsonConverterIImplUnderTest.convertJSONtoXMLInterface("src/test/resources/json/example1.json", "src/test/resources/xml/OutputFileExistExample.xml");

        // Verify the results
    }

    /**
     * Test convert jso nto xml interface with file exist.
     *
     * @throws Exception the exception
     */
    @Test
    public void  testConvertJSONtoXMLInterfaceWithFileExist() throws Exception {
        File outputXmlFile = new File("src/test/resources/xml/OutputFileExist.xml");
        outputXmlFile.createNewFile();
        // Run the test
        xmljsonConverterIImplUnderTest.convertJSONtoXMLInterface("src/test/resources/json/example1.json", "src/test/resources/xml/OutputFileExist.xml");
    }

    /**
     * Test convert jso nto xml interface with directory.
     *
     * @throws Exception the exception
     */
    @Test
    public void  testConvertJSONtoXMLInterfaceWithDirectory() throws Exception {
        // Run the test
        xmljsonConverterIImplUnderTest.convertJSONtoXMLInterface("src/test/resources/json/example1.json", "src/test/resources/xml/");
    }

    /**
     * Test convert jso nto xml interface with file not exist.
     *
     * @throws Exception the exception
     */
    @Test
    public void  testConvertJSONtoXMLInterfaceWithFileNotExist() throws Exception {
        // Run the test
        xmljsonConverterIImplUnderTest.convertJSONtoXMLInterface("src/test/resources/json/example1.json", "src/test/resources/xml/a.xml");
    }

    /**
     * Test convert jso nto xml interface throws io exception.
     *
     * @throws Exception the exception
     */
    @Test(expected = IOException.class)
    public void testConvertJSONtoXMLInterface_ThrowsIOException() throws Exception {
        // Setup

        // Run the test
        xmljsonConverterIImplUnderTest.convertJSONtoXMLInterface("inputFileName", "outputFileName");
    }

    /**
     * Test convert jso nto xml interface throws parse exception.
     *
     * @throws Exception the exception
     */
    @Test(expected = ParseException.class)
    public void testConvertJSONtoXMLInterface_ThrowsParseException() throws Exception {
        // Setup

        // Run the test
        xmljsonConverterIImplUnderTest.convertJSONtoXMLInterface("src/test/resources/json/example.json", "outputFileName");
    }

    /**
     * Test read json.
     */
    @Test
    public void testReadJson() {
        assertEquals("", XMLJSONConverterIImpl.readJson("obj"));
    }

    /**
     * Test pretty print xml.
     */
    @Test
    public void testPrettyPrintXml() {
        assertEquals(null, XMLJSONConverterIImpl.prettyPrintXml("xmlStringToBeFormatted"));
    }
}
