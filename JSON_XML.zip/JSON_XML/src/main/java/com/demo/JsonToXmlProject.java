//Main Java program
package com.demo;


/**
 * The type Json to xml project.
 */
public class JsonToXmlProject {
    /**
     * The entry point of application.
     *
     * @param args the input arguments
     * @throws Exception the exception
     */
    public static void main(String[] args) throws Exception {
        //Validation for args[]
        if (args.length < 2 || args.length > 2) {
            System.out.println("Usage : java JsonToXmlProject <<Input Json File Path>> <<Output XML File Path>>.Kindly re-verify the parameter passed");
            throw new Exception("Invalid Arguments");
        }

        //Creating the instance of the Factory file which creates the instance of XMLJSONCovnerterI
        ConverterFactory converterMethod = new ConverterFactory();

        //get an object of convertJsonToXml and call its convertJSONtoXML method.
        XMLJSONConverterI jsonToXmlConversion = converterMethod.convertJsonToXml(args[0], args[1]);

        //call convertJSONtoXMLInterface method
        jsonToXmlConversion.convertJSONtoXMLInterface(args[0], args[1]);
    }
}
