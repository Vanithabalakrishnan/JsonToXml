package com.demo;

import org.json.simple.parser.ParseException;

import java.io.IOException;

public interface XMLJSONConverterI {
    public void convertJSONtoXMLInterface (String inputFileName, String outputFileName) throws IOException, ParseException;
}
