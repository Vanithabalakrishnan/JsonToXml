package com.demo;

/**
 * The type Converter factory.
 */
public class ConverterFactory {
    /**
     * convertJsonToXml method to get object of type XMLJSONConverterI
     *
     * @param inputJsonFileName the input json file name
     * @param outputXmlFileName the output xml file name
     * @return the xmljson converter i
     */

    public XMLJSONConverterI convertJsonToXml(String inputJsonFileName, String outputXmlFileName){
        return new XMLJSONConverterIImpl(inputJsonFileName, outputXmlFileName);
    }
}

