package com.demo;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Iterator;

public class XMLJSONConverterIImpl implements XMLJSONConverterI {

    /**
     * Instantiates a new Xmljson converter i.
     *
     * @param inputJsonFileName the input json file name
     * @param outputXmlFileName the output xml file name
     */
    public XMLJSONConverterIImpl(String inputJsonFileName, String outputXmlFileName) {
    }

    @Override
    public void convertJSONtoXMLInterface(String inputFileName, String outputFileName) throws IOException, ParseException {
        FileReader filenamePath = null;
        try {
            filenamePath = new FileReader(inputFileName);
        } catch (FileNotFoundException e) {
            throw new FileNotFoundException("Input File is not found in the path specified in the output arguments");
        }
        Object obj = new JSONParser().parse(filenamePath);
        StringBuilder jsonStr = new StringBuilder();
        if (obj instanceof JSONObject) {
            jsonStr.append("<object>");
            jsonStr.append(readJson(obj));
            jsonStr.append("</object>");
        } else if (obj instanceof JSONArray) {
            jsonStr.append("<array>");
            jsonStr.append(readJson(obj));
            jsonStr.append("</array>");
        }

        try {
            Path outPutPath = Paths.get(outputFileName);
            if (Files.isDirectory(outPutPath)) {
                File file = new File(outputFileName + "Output.xml");
                file.createNewFile();
                FileWriter fileWrite = new FileWriter(outputFileName + "Output.xml");
                fileWrite.write(prettyPrintXml(jsonStr.toString()));
                fileWrite.close();
            } else {
                File outputXmlFile = new File(outputFileName);
                if (outputXmlFile.exists()) {
                    FileWriter fileWriteExist = new FileWriter(outputFileName);
                    fileWriteExist.write(prettyPrintXml(jsonStr.toString()));
                    fileWriteExist.close();
                } else {
                    outputXmlFile.createNewFile();
                    FileWriter fileWriteNew = new FileWriter(outputXmlFile);
                    fileWriteNew.write(prettyPrintXml(jsonStr.toString()));
                    fileWriteNew.close();
                }
            }
        } catch (IOException e) {
            FileWriter file = new FileWriter(outputFileName);
            file.write(jsonStr.toString());
            file.close();
        }
    }

    /**
     * Read json string.
     *
     * @param obj the obj
     * @return the string
     */
    public static String readJson(Object obj) {
        StringBuilder jsonStr = new StringBuilder();
        if (obj instanceof JSONObject) {
            // typecasting obj to JSONObject
            JSONObject jsonObject = (JSONObject) obj;
            Iterator<String> keys = jsonObject.keySet().iterator();
            while (keys.hasNext()) {
                String key = keys.next();
                if (jsonObject.get(key) == null) {
                    jsonStr.append("<null name=\"" + key + "\"/>");
                } else if (jsonObject.get(key) instanceof JSONObject) {
                    jsonStr.append("<object name=\"" + key + "\">");
                    jsonStr.append(readJson(jsonObject.get(key)));
                    jsonStr.append("</object>");
                } else if (jsonObject.get(key) instanceof JSONArray) {
                    jsonStr.append("<array name=\"" + key + "\">");
                    jsonStr.append(readJson(jsonObject.get(key)));
                    jsonStr.append("</array>");
                } else if (jsonObject.get(key) instanceof String) {
                    jsonStr.append("<string name=\"" + key + "\">");
                    jsonStr.append(jsonObject.get(key));
                    jsonStr.append("</string>");
                } else if (jsonObject.get(key) instanceof Number) {
                    jsonStr.append("<number name=\"" + key + "\">");
                    jsonStr.append(jsonObject.get(key));
                    jsonStr.append("</number>");
                } else if (jsonObject.get(key) instanceof Boolean) {
                    jsonStr.append("<boolean name=\"" + key + "\">");
                    jsonStr.append(jsonObject.get(key));
                    jsonStr.append("</boolean>");
                }
            }
        } else if (obj instanceof JSONArray) {
            JSONArray jsonArray = (JSONArray) obj;
            Iterator<Object> values = jsonArray.iterator();
            while (values.hasNext()) {
                Object val = values.next();
                if (val instanceof JSONObject) {
                    jsonStr.append("<object>");
                    jsonStr.append(readJson(val));
                    jsonStr.append("</object>");
                } else if (val instanceof JSONArray) {
                    jsonStr.append("<array>");
                    jsonStr.append(readJson(val));
                    jsonStr.append("</array>");
                } else if (val instanceof String) {
                    jsonStr.append("<string>");
                    jsonStr.append(val);
                    jsonStr.append("</string>");
                } else if (val instanceof Number) {
                    jsonStr.append("<number>");
                    jsonStr.append(val);
                    jsonStr.append("</number>");
                } else if (val instanceof Boolean) {
                    jsonStr.append("<boolean>");
                    jsonStr.append(val);
                    jsonStr.append("</boolean>");
                }
            }
        }
        return jsonStr.toString();
    }

    /**
     * Pretty print xml string.
     *
     * @param xmlStringToBeFormatted the xml string to be formatted
     * @return the string
     */
    public static String prettyPrintXml(String xmlStringToBeFormatted) {
        String formattedXmlString = null;
        try {
            DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
            documentBuilderFactory.setValidating(true);
            DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
            InputSource inputSource = new InputSource(new StringReader(xmlStringToBeFormatted));
            Document document = documentBuilder.parse(inputSource);

            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");

            StreamResult streamResult = new StreamResult(new StringWriter());
            DOMSource dOMSource = new DOMSource(document);
            transformer.transform(dOMSource, streamResult);
            formattedXmlString = streamResult.getWriter().toString().trim();
        } catch (Exception ex) {
        }
        return formattedXmlString;
    }
}
